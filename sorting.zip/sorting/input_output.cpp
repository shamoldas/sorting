#include<iostream>
using namespace std;
int main()
{
	int a,b,i,n;
	cout<<"enter_two_number.\n";
	cin>>a>>b;
	n=a+b;
	if(n==5)
	{
		cout<<"cool.\n";
	}
	return 0;
}
